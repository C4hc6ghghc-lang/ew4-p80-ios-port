'use strict';
(function(root,factory){
  const api=factory();
  if(typeof module==='object'&&module.exports)module.exports=api;
  if(root)root.EW4NativeCamera=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(){
  // libeuropean-war-4.so CEntityCamera / battle gesture constants.
  // x86_64 audit: CEntityCamera::set @ 0x7f3e0, battle touch handlers @ 0x9fe40..0xa0758.
  const MIN_ZOOM=0.2;
  const MAX_ZOOM=1.0;
  const DETAIL_ZOOM=0.5;
  const TAP_AXIS_SLOP=15;
  const PINCH_MIN_DISTANCE=40;
  const VIEW_CX=284;
  const VIEW_CY=160;
  const PAN_EDGE_MARGIN=16;

  const clamp=(v,lo,hi)=>Math.max(lo,Math.min(hi,v));
  function clampZoom(z){return clamp(Number.isFinite(+z)?+z:1,MIN_ZOOM,MAX_ZOOM)}
  function detailInteractionEnabled(z){return +z>=DETAIL_ZOOM}
  function isNativeTap(start,end){
    if(!start||!end)return false;
    // Native release path compares each axis independently against 15.0f.
    return Math.abs(+end.x-(+start.x))<TAP_AXIS_SLOP&&Math.abs(+end.y-(+start.y))<TAP_AXIS_SLOP;
  }
  function screenToWorld(camera,x,y,cx=VIEW_CX,cy=VIEW_CY){
    const z=+camera.zoom||1;
    return{x:(+x-cx)/z+(+camera.x||0),y:(+y-cy)/z+(+camera.y||0)};
  }
  function zoomAt(camera,nextZoom,sx=VIEW_CX,sy=VIEW_CY,worldAnchor=null,cx=VIEW_CX,cy=VIEW_CY){
    const anchor=worldAnchor||screenToWorld(camera,sx,sy,cx,cy),z=clampZoom(nextZoom);
    return{x:anchor.x-(sx-cx)/z,y:anchor.y-(sy-cy)/z,zoom:z};
  }
  function panStep(camera,previous,current){
    if(!camera||!previous||!current)return null;
    const z=+camera.zoom||1;
    // Native one-finger move: camera += (previousTouch-currentTouch)/zoom.
    return{x:(+camera.x||0)+(+previous.x-(+current.x))/z,y:(+camera.y||0)+(+previous.y-(+current.y))/z,zoom:z};
  }
  function pinchStep(camera,movedBefore,movedAfter,stationary,cx=VIEW_CX,cy=VIEW_CY){
    if(!camera||!movedBefore||!movedAfter||!stationary)return{applied:false,camera:{...camera}};
    const oldDist=Math.hypot(+movedBefore.x-(+stationary.x),+movedBefore.y-(+stationary.y));
    const newDist=Math.hypot(+movedAfter.x-(+stationary.x),+movedAfter.y-(+stationary.y));
    // Native applies pinch only when BOTH separations exceed 40 logical pixels.
    if(!(oldDist>PINCH_MIN_DISTANCE&&newDist>PINCH_MIN_DISTANCE))return{applied:false,oldDist,newDist,camera:{...camera}};
    // Native anchors the stationary finger's world point for each incremental pointer event.
    const anchor=screenToWorld(camera,stationary.x,stationary.y,cx,cy);
    const z=clampZoom((+camera.zoom||1)*(newDist/oldDist));
    return{applied:true,oldDist,newDist,anchor,camera:{x:anchor.x-(+stationary.x-cx)/z,y:anchor.y-(+stationary.y-cy)/z,zoom:z}};
  }
  return{MIN_ZOOM,MAX_ZOOM,DETAIL_ZOOM,TAP_AXIS_SLOP,PINCH_MIN_DISTANCE,VIEW_CX,VIEW_CY,PAN_EDGE_MARGIN,clampZoom,detailInteractionEnabled,isNativeTap,screenToWorld,zoomAt,panStep,pinchStep};
});
