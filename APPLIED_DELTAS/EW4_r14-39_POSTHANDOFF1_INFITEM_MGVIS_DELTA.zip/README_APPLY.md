# Apply r14-39 post-handoff patch 1

Base required: `EW4_R14_39_HANDOFF_2026-09-08_2254.zip` source tree.

Overlay the included `EW4_Web_Port_v0.61/` directory on the baseline `SOURCE_LEAN/EW4_Web_Port_v0.61/` work tree, allowing same-path files to replace the baseline versions.

This patch intentionally changes only the player infinite-resource / battle-consumable scope and the first mainline combat-visual micro-batch (machine-gun `effect_mgunfire.xml`).

Expected regression result after the APK fixture is available at `/mnt/data/ew4_apk_extract`: 58/58 PASS.
